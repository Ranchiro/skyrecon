import React, { useState, useEffect } from 'react';
import { Header } from './components/Layout/Header';
import { StatsCards } from './components/Dashboard/StatsCards';
import { ChartsSection } from './components/Dashboard/ChartsSection';
import { IOCTable } from './components/Dashboard/IOCTable';
import { iocService } from './services/iocService';
import { IOC, DashboardStats } from './types/ioc';

function App() {
  const [iocs, setIOCs] = useState<IOC[]>([]);
  const [filteredIOCs, setFilteredIOCs] = useState<IOC[]>([]);
  const [stats, setStats] = useState<DashboardStats | null>(null);
  const [loading, setLoading] = useState(true);
  const [notification, setNotification] = useState<{
    type: 'success' | 'error';
    message: string;
  } | null>(null);

  useEffect(() => {
    loadData();
    // Simulate real-time updates
    const interval = setInterval(() => {
      loadData();
    }, 30000); // Update every 30 seconds

    return () => clearInterval(interval);
  }, []);

  const loadData = async () => {
    try {
      const [iocsData, statsData] = await Promise.all([
        iocService.getAllIOCs(),
        iocService.getDashboardStats()
      ]);
      
      setIOCs(iocsData);
      setFilteredIOCs(iocsData);
      setStats(statsData);
    } catch (error) {
      console.error('Failed to load data:', error);
      showNotification('error', 'Failed to load threat intelligence data');
    } finally {
      setLoading(false);
    }
  };

  const handleSearch = async (query: string) => {
    try {
      const results = await iocService.searchIOCs(query);
      setFilteredIOCs(results);
    } catch (error) {
      console.error('Search failed:', error);
      showNotification('error', 'Search failed');
    }
  };

  const handleFilter = async (filters: any) => {
    try {
      const results = await iocService.searchIOCs('', filters);
      setFilteredIOCs(results);
    } catch (error) {
      console.error('Filter failed:', error);
      showNotification('error', 'Filter failed');
    }
  };

  const handleExport = async (format: 'json' | 'csv') => {
    try {
      const data = await iocService.exportIOCs(format);
      const blob = new Blob([data], { 
        type: format === 'json' ? 'application/json' : 'text/csv' 
      });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `skyrecon-iocs-${new Date().toISOString().split('T')[0]}.${format}`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
      
      showNotification('success', `IOCs exported as ${format.toUpperCase()}`);
    } catch (error) {
      console.error('Export failed:', error);
      showNotification('error', 'Export failed');
    }
  };

  const handleUpload = async (file: File) => {
    try {
      const result = await iocService.uploadIOCs(file);
      if (result.success) {
        showNotification('success', result.message);
        loadData(); // Refresh data
      } else {
        showNotification('error', result.message);
      }
    } catch (error) {
      console.error('Upload failed:', error);
      showNotification('error', 'Upload failed');
    }
  };

  const showNotification = (type: 'success' | 'error', message: string) => {
    setNotification({ type, message });
    setTimeout(() => setNotification(null), 5000);
  };

  return (
    <div className="min-h-screen bg-gray-900">
      <Header />
      
      <main className="p-6">
        <div className="max-w-7xl mx-auto space-y-8">
          <StatsCards stats={stats} loading={loading} />
          <ChartsSection stats={stats} loading={loading} />
          <IOCTable
            iocs={filteredIOCs}
            loading={loading}
            onSearch={handleSearch}
            onFilter={handleFilter}
            onExport={handleExport}
            onUpload={handleUpload}
          />
        </div>
      </main>

      {/* Notification Toast */}
      {notification && (
        <div className={`fixed top-4 right-4 p-4 rounded-lg shadow-lg z-50 ${
          notification.type === 'success' 
            ? 'bg-green-600 text-white' 
            : 'bg-red-600 text-white'
        }`}>
          <div className="flex items-center justify-between">
            <span>{notification.message}</span>
            <button
              onClick={() => setNotification(null)}
              className="ml-4 text-white hover:text-gray-200"
            >
              ✕
            </button>
          </div>
        </div>
      )}
    </div>
  );
}

export default App;