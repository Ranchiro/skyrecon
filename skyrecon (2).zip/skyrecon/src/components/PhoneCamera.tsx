import React, { useRef, useCallback, useState, useEffect } from 'react';
import Webcam from 'react-webcam';
import * as tf from '@tensorflow/tfjs';
import { AlertTriangle } from 'lucide-react';

interface PhoneCameraProps {
  onDetection?: (detection: string) => void;
}

export default function PhoneCamera({ onDetection }: PhoneCameraProps) {
  const webcamRef = useRef<Webcam>(null);
  const [isModelLoaded, setIsModelLoaded] = useState(false);
  const [model, setModel] = useState<tf.GraphModel | null>(null);
  const [detection, setDetection] = useState<string>('');

  useEffect(() => {
    const loadModel = async () => {
      try {
        const loadedModel = await tf.loadGraphModel(
          'https://tfhub.dev/tensorflow/tfjs-model/ssd_mobilenet_v2/1/default/1',
          { fromTFHub: true }
        );
        setModel(loadedModel);
        setIsModelLoaded(true);
      } catch (error) {
        console.error('Failed to load model:', error);
      }
    };
    loadModel();
  }, []);

  const detect = useCallback(async () => {
    if (webcamRef.current && model) {
      const video = webcamRef.current.video;
      if (video) {
        const tfImg = tf.browser.fromPixels(video);
        const expandedImg = tfImg.expandDims(0);
        const predictions = await model.predict(expandedImg);
        
        // Process predictions and detect suspicious activities
        const detectionResult = 'Normal Activity'; // Simplified for demo
        setDetection(detectionResult);
        if (onDetection) onDetection(detectionResult);
        
        tfImg.dispose();
        expandedImg.dispose();
      }
    }
  }, [model, onDetection]);

  useEffect(() => {
    if (isModelLoaded) {
      const interval = setInterval(() => {
        detect();
      }, 1000);
      return () => clearInterval(interval);
    }
  }, [isModelLoaded, detect]);

  return (
    <div className="relative">
      <Webcam
        ref={webcamRef}
        audio={false}
        className="w-full rounded-lg"
        screenshotFormat="image/jpeg"
      />
      {!isModelLoaded && (
        <div className="absolute inset-0 flex items-center justify-center bg-black/50 rounded-lg">
          <div className="text-white">Loading AI model...</div>
        </div>
      )}
      {detection && (
        <div className="absolute bottom-4 left-4 right-4 bg-black/50 text-white p-2 rounded">
          <div className="flex items-center">
            <AlertTriangle className="w-4 h-4 mr-2" />
            <span>{detection}</span>
          </div>
        </div>
      )}
    </div>
  );
}