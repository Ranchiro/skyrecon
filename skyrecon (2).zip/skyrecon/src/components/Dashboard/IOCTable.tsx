import React, { useState, useMemo } from 'react';
import { Search, Filter, Download, Upload, Eye, AlertCircle, CheckCircle, Clock } from 'lucide-react';
import { IOC } from '../../types/ioc';
import { format } from 'date-fns';
import { clsx } from 'clsx';

interface IOCTableProps {
  iocs: IOC[];
  loading: boolean;
  onSearch: (query: string) => void;
  onFilter: (filters: any) => void;
  onExport: (format: 'json' | 'csv') => void;
  onUpload: (file: File) => void;
}

export const IOCTable: React.FC<IOCTableProps> = ({
  iocs,
  loading,
  onSearch,
  onFilter,
  onExport,
  onUpload
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedType, setSelectedType] = useState('all');
  const [selectedSource, setSelectedSource] = useState('all');
  const [sortField, setSortField] = useState<keyof IOC>('firstSeen');
  const [sortDirection, setSortDirection] = useState<'asc' | 'desc'>('desc');
  const [currentPage, setCurrentPage] = useState(1);
  const [selectedIOC, setSelectedIOC] = useState<IOC | null>(null);
  const itemsPerPage = 50;

  const uniqueTypes = ['all', ...Array.from(new Set(iocs.map(ioc => ioc.type)))];
  const uniqueSources = ['all', ...Array.from(new Set(iocs.map(ioc => ioc.source)))];

  const filteredAndSortedIOCs = useMemo(() => {
    let filtered = iocs;

    if (searchQuery) {
      const query = searchQuery.toLowerCase();
      filtered = filtered.filter(ioc =>
        ioc.value.toLowerCase().includes(query) ||
        ioc.source.toLowerCase().includes(query) ||
        ioc.tags.some(tag => tag.toLowerCase().includes(query))
      );
    }

    if (selectedType !== 'all') {
      filtered = filtered.filter(ioc => ioc.type === selectedType);
    }

    if (selectedSource !== 'all') {
      filtered = filtered.filter(ioc => ioc.source === selectedSource);
    }

    return filtered.sort((a, b) => {
      const aVal = a[sortField];
      const bVal = b[sortField];
      
      if (aVal instanceof Date && bVal instanceof Date) {
        return sortDirection === 'asc' ? aVal.getTime() - bVal.getTime() : bVal.getTime() - aVal.getTime();
      }
      
      if (typeof aVal === 'string' && typeof bVal === 'string') {
        return sortDirection === 'asc' ? aVal.localeCompare(bVal) : bVal.localeCompare(aVal);
      }
      
      if (typeof aVal === 'number' && typeof bVal === 'number') {
        return sortDirection === 'asc' ? aVal - bVal : bVal - aVal;
      }
      
      return 0;
    });
  }, [iocs, searchQuery, selectedType, selectedSource, sortField, sortDirection]);

  const paginatedIOCs = useMemo(() => {
    const startIndex = (currentPage - 1) * itemsPerPage;
    return filteredAndSortedIOCs.slice(startIndex, startIndex + itemsPerPage);
  }, [filteredAndSortedIOCs, currentPage]);

  const totalPages = Math.ceil(filteredAndSortedIOCs.length / itemsPerPage);

  const handleSort = (field: keyof IOC) => {
    if (sortField === field) {
      setSortDirection(prev => prev === 'asc' ? 'desc' : 'asc');
    } else {
      setSortField(field);
      setSortDirection('desc');
    }
  };

  const handleSearch = (query: string) => {
    setSearchQuery(query);
    setCurrentPage(1);
    onSearch(query);
  };

  const getThreatScoreColor = (score: number) => {
    if (score >= 80) return 'text-red-400 bg-red-900/20';
    if (score >= 60) return 'text-orange-400 bg-orange-900/20';
    if (score >= 40) return 'text-yellow-400 bg-yellow-900/20';
    return 'text-green-400 bg-green-900/20';
  };

  const getStatusIcon = (status: IOC['status']) => {
    switch (status) {
      case 'active':
        return <AlertCircle className="w-4 h-4 text-red-400" />;
      case 'inactive':
        return <CheckCircle className="w-4 h-4 text-green-400" />;
      case 'investigating':
        return <Clock className="w-4 h-4 text-yellow-400" />;
    }
  };

  const handleFileUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      onUpload(file);
    }
  };

  return (
    <div className="bg-gray-800 rounded-xl border border-gray-700">
      {/* Header */}
      <div className="p-6 border-b border-gray-700">
        <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between gap-4">
          <h2 className="text-xl font-semibold text-white">Indicators of Compromise</h2>
          
          <div className="flex flex-col sm:flex-row gap-3">
            <div className="relative">
              <Search className="w-5 h-5 absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" />
              <input
                type="text"
                placeholder="Search IOCs..."
                value={searchQuery}
                onChange={(e) => handleSearch(e.target.value)}
                className="pl-10 pr-4 py-2 bg-gray-700 border border-gray-600 rounded-lg text-white placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-blue-500 w-full sm:w-64"
              />
            </div>
            
            <select
              value={selectedType}
              onChange={(e) => setSelectedType(e.target.value)}
              className="px-4 py-2 bg-gray-700 border border-gray-600 rounded-lg text-white focus:outline-none focus:ring-2 focus:ring-blue-500"
            >
              {uniqueTypes.map(type => (
                <option key={type} value={type}>
                  {type === 'all' ? 'All Types' : type.toUpperCase()}
                </option>
              ))}
            </select>

            <select
              value={selectedSource}
              onChange={(e) => setSelectedSource(e.target.value)}
              className="px-4 py-2 bg-gray-700 border border-gray-600 rounded-lg text-white focus:outline-none focus:ring-2 focus:ring-blue-500"
            >
              {uniqueSources.map(source => (
                <option key={source} value={source}>
                  {source === 'all' ? 'All Sources' : source}
                </option>
              ))}
            </select>

            <div className="flex gap-2">
              <button
                onClick={() => onExport('json')}
                className="px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-lg transition-colors flex items-center gap-2"
              >
                <Download className="w-4 h-4" />
                JSON
              </button>
              
              <button
                onClick={() => onExport('csv')}
                className="px-4 py-2 bg-green-600 hover:bg-green-700 text-white rounded-lg transition-colors flex items-center gap-2"
              >
                <Download className="w-4 h-4" />
                CSV
              </button>

              <label className="px-4 py-2 bg-orange-600 hover:bg-orange-700 text-white rounded-lg transition-colors flex items-center gap-2 cursor-pointer">
                <Upload className="w-4 h-4" />
                Upload
                <input
                  type="file"
                  accept=".csv,.json"
                  onChange={handleFileUpload}
                  className="hidden"
                />
              </label>
            </div>
          </div>
        </div>
      </div>

      {/* Table */}
      <div className="overflow-x-auto">
        <table className="w-full">
          <thead className="bg-gray-700/50">
            <tr>
              <th className="px-6 py-4 text-left text-xs font-medium text-gray-300 uppercase tracking-wider cursor-pointer hover:text-white"
                  onClick={() => handleSort('type')}>
                Type
              </th>
              <th className="px-6 py-4 text-left text-xs font-medium text-gray-300 uppercase tracking-wider cursor-pointer hover:text-white"
                  onClick={() => handleSort('value')}>
                Value
              </th>
              <th className="px-6 py-4 text-left text-xs font-medium text-gray-300 uppercase tracking-wider cursor-pointer hover:text-white"
                  onClick={() => handleSort('source')}>
                Source
              </th>
              <th className="px-6 py-4 text-left text-xs font-medium text-gray-300 uppercase tracking-wider cursor-pointer hover:text-white"
                  onClick={() => handleSort('firstSeen')}>
                First Seen
              </th>
              <th className="px-6 py-4 text-left text-xs font-medium text-gray-300 uppercase tracking-wider cursor-pointer hover:text-white"
                  onClick={() => handleSort('threatScore')}>
                Threat Score
              </th>
              <th className="px-6 py-4 text-left text-xs font-medium text-gray-300 uppercase tracking-wider">
                Tags
              </th>
              <th className="px-6 py-4 text-left text-xs font-medium text-gray-300 uppercase tracking-wider cursor-pointer hover:text-white"
                  onClick={() => handleSort('status')}>
                Status
              </th>
              <th className="px-6 py-4 text-left text-xs font-medium text-gray-300 uppercase tracking-wider">
                Actions
              </th>
            </tr>
          </thead>
          <tbody className="divide-y divide-gray-700">
            {loading ? (
              Array.from({ length: 10 }).map((_, i) => (
                <tr key={i} className="animate-pulse">
                  <td className="px-6 py-4"><div className="h-4 bg-gray-700 rounded w-16"></div></td>
                  <td className="px-6 py-4"><div className="h-4 bg-gray-700 rounded w-32"></div></td>
                  <td className="px-6 py-4"><div className="h-4 bg-gray-700 rounded w-24"></div></td>
                  <td className="px-6 py-4"><div className="h-4 bg-gray-700 rounded w-20"></div></td>
                  <td className="px-6 py-4"><div className="h-4 bg-gray-700 rounded w-12"></div></td>
                  <td className="px-6 py-4"><div className="h-4 bg-gray-700 rounded w-40"></div></td>
                  <td className="px-6 py-4"><div className="h-4 bg-gray-700 rounded w-16"></div></td>
                  <td className="px-6 py-4"><div className="h-4 bg-gray-700 rounded w-8"></div></td>
                </tr>
              ))
            ) : (
              paginatedIOCs.map((ioc) => (
                <tr key={ioc.id} className="hover:bg-gray-700/30 transition-colors">
                  <td className="px-6 py-4 whitespace-nowrap">
                    <span className={clsx(
                      'inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium uppercase',
                      {
                        'bg-blue-900/30 text-blue-300': ioc.type === 'ip',
                        'bg-green-900/30 text-green-300': ioc.type === 'domain',
                        'bg-purple-900/30 text-purple-300': ioc.type === 'hash',
                        'bg-yellow-900/30 text-yellow-300': ioc.type === 'url',
                        'bg-red-900/30 text-red-300': ioc.type === 'email',
                      }
                    )}>
                      {ioc.type}
                    </span>
                  </td>
                  <td className="px-6 py-4 text-white font-mono text-sm">
                    {ioc.value.length > 50 ? `${ioc.value.substring(0, 50)}...` : ioc.value}
                  </td>
                  <td className="px-6 py-4 text-gray-300">{ioc.source}</td>
                  <td className="px-6 py-4 text-gray-300 text-sm">
                    {format(ioc.firstSeen, 'MMM dd, HH:mm')}
                  </td>
                  <td className="px-6 py-4">
                    <span className={clsx(
                      'inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium',
                      getThreatScoreColor(ioc.threatScore)
                    )}>
                      {ioc.threatScore}
                    </span>
                  </td>
                  <td className="px-6 py-4">
                    <div className="flex flex-wrap gap-1">
                      {ioc.tags.slice(0, 3).map((tag, i) => (
                        <span key={i} className="inline-flex items-center px-2 py-1 rounded-md text-xs bg-gray-700 text-gray-300">
                          {tag}
                        </span>
                      ))}
                      {ioc.tags.length > 3 && (
                        <span className="inline-flex items-center px-2 py-1 rounded-md text-xs bg-gray-600 text-gray-400">
                          +{ioc.tags.length - 3}
                        </span>
                      )}
                    </div>
                  </td>
                  <td className="px-6 py-4">
                    <div className="flex items-center gap-2">
                      {getStatusIcon(ioc.status)}
                      <span className="text-xs text-gray-400 capitalize">{ioc.status}</span>
                    </div>
                  </td>
                  <td className="px-6 py-4">
                    <button
                      onClick={() => setSelectedIOC(ioc)}
                      className="text-blue-400 hover:text-blue-300 transition-colors"
                    >
                      <Eye className="w-4 h-4" />
                    </button>
                  </td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>

      {/* Pagination */}
      <div className="px-6 py-4 border-t border-gray-700 flex items-center justify-between">
        <div className="text-sm text-gray-400">
          Showing {Math.min((currentPage - 1) * itemsPerPage + 1, filteredAndSortedIOCs.length)} to{' '}
          {Math.min(currentPage * itemsPerPage, filteredAndSortedIOCs.length)} of {filteredAndSortedIOCs.length} results
        </div>
        <div className="flex items-center gap-2">
          <button
            onClick={() => setCurrentPage(prev => Math.max(1, prev - 1))}
            disabled={currentPage === 1}
            className="px-3 py-1 rounded border border-gray-600 text-gray-300 hover:bg-gray-700 disabled:opacity-50 disabled:cursor-not-allowed"
          >
            Previous
          </button>
          <span className="px-3 py-1 text-gray-300">
            Page {currentPage} of {totalPages}
          </span>
          <button
            onClick={() => setCurrentPage(prev => Math.min(totalPages, prev + 1))}
            disabled={currentPage === totalPages}
            className="px-3 py-1 rounded border border-gray-600 text-gray-300 hover:bg-gray-700 disabled:opacity-50 disabled:cursor-not-allowed"
          >
            Next
          </button>
        </div>
      </div>

      {/* IOC Details Modal */}
      {selectedIOC && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
          <div className="bg-gray-800 rounded-xl max-w-2xl w-full max-h-[80vh] overflow-y-auto">
            <div className="p-6 border-b border-gray-700">
              <div className="flex items-center justify-between">
                <h3 className="text-lg font-semibold text-white">IOC Details</h3>
                <button
                  onClick={() => setSelectedIOC(null)}
                  className="text-gray-400 hover:text-white"
                >
                  ✕
                </button>
              </div>
            </div>
            <div className="p-6 space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="text-sm text-gray-400">Type</label>
                  <p className="text-white font-medium uppercase">{selectedIOC.type}</p>
                </div>
                <div>
                  <label className="text-sm text-gray-400">Threat Score</label>
                  <p className="text-white font-medium">{selectedIOC.threatScore}/100</p>
                </div>
                <div>
                  <label className="text-sm text-gray-400">Source</label>
                  <p className="text-white font-medium">{selectedIOC.source}</p>
                </div>
                <div>
                  <label className="text-sm text-gray-400">Confidence</label>
                  <p className="text-white font-medium">{selectedIOC.confidence}%</p>
                </div>
              </div>
              
              <div>
                <label className="text-sm text-gray-400">Value</label>
                <p className="text-white font-mono bg-gray-700 p-2 rounded mt-1 break-all">
                  {selectedIOC.value}
                </p>
              </div>

              <div>
                <label className="text-sm text-gray-400">Tags</label>
                <div className="flex flex-wrap gap-2 mt-1">
                  {selectedIOC.tags.map((tag, i) => (
                    <span key={i} className="px-2 py-1 bg-blue-600 text-white text-xs rounded">
                      {tag}
                    </span>
                  ))}
                </div>
              </div>

              <div>
                <label className="text-sm text-gray-400">Enriched Data</label>
                <div className="bg-gray-700 p-3 rounded mt-1 space-y-2">
                  {Object.entries(selectedIOC.enrichedData).map(([key, value]) => (
                    <div key={key} className="flex justify-between">
                      <span className="text-gray-300 capitalize">{key.replace(/([A-Z])/g, ' $1')}</span>
                      <span className="text-white">{value || 'N/A'}</span>
                    </div>
                  ))}
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="text-sm text-gray-400">First Seen</label>
                  <p className="text-white">{format(selectedIOC.firstSeen, 'PPpp')}</p>
                </div>
                <div>
                  <label className="text-sm text-gray-400">Last Seen</label>
                  <p className="text-white">{format(selectedIOC.lastSeen, 'PPpp')}</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};