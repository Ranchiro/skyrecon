import React from 'react';
import { Shield, AlertTriangle, TrendingUp, Target } from 'lucide-react';
import { DashboardStats } from '../../types/ioc';

interface StatsCardsProps {
  stats: DashboardStats | null;
  loading: boolean;
}

export const StatsCards: React.FC<StatsCardsProps> = ({ stats, loading }) => {
  const cards = [
    {
      title: 'Total IOCs',
      value: stats?.totalIOCs || 0,
      icon: Shield,
      color: 'from-blue-500 to-blue-600',
      change: '+12%'
    },
    {
      title: 'Active Threats',
      value: stats?.activeThreats || 0,
      icon: AlertTriangle,
      color: 'from-red-500 to-red-600',
      change: '-8%'
    },
    {
      title: 'New Today',
      value: stats?.newToday || 0,
      icon: TrendingUp,
      color: 'from-green-500 to-green-600',
      change: '+23%'
    },
    {
      title: 'High Risk',
      value: stats?.highRiskIOCs || 0,
      icon: Target,
      color: 'from-orange-500 to-orange-600',
      change: '+5%'
    }
  ];

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
      {cards.map((card, index) => {
        const IconComponent = card.icon;
        return (
          <div key={index} className="bg-gray-800 rounded-xl p-6 border border-gray-700 hover:border-gray-600 transition-colors">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-gray-400 text-sm font-medium">{card.title}</p>
                <p className="text-2xl font-bold text-white mt-1">
                  {loading ? '...' : card.value.toLocaleString()}
                </p>
                <p className="text-sm text-green-400 mt-1">{card.change} from last week</p>
              </div>
              <div className={`w-12 h-12 rounded-lg bg-gradient-to-r ${card.color} flex items-center justify-center`}>
                <IconComponent className="w-6 h-6 text-white" />
              </div>
            </div>
          </div>
        );
      })}
    </div>
  );
};