import React from 'react';
import { Camera, Activity, Users, AlertTriangle } from 'lucide-react';

const stats = [
  { name: 'Active Cameras', value: '12', icon: Camera, change: '+2', changeType: 'increase' },
  { name: 'Daily Events', value: '145', icon: Activity, change: '+12%', changeType: 'increase' },
  { name: 'Active Users', value: '23', icon: Users, change: '-1', changeType: 'decrease' },
  { name: 'Critical Alerts', value: '3', icon: AlertTriangle, change: '+1', changeType: 'increase' },
];

const recentAlerts = [
  {
    id: 1,
    type: 'Motion Detected',
    location: 'Front Entrance',
    time: '2 minutes ago',
    image: 'https://images.unsplash.com/photo-1590674899484-d5640e854abe?ixlib=rb-1.2.1&auto=format&fit=crop&w=300&q=80',
  },
  {
    id: 2,
    type: 'Person Detected',
    location: 'Parking Lot',
    time: '15 minutes ago',
    image: 'https://images.unsplash.com/photo-1576427743731-00f27173f10f?ixlib=rb-1.2.1&auto=format&fit=crop&w=300&q=80',
  },
];

export default function Dashboard() {
  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-4">
        {stats.map((stat) => (
          <div key={stat.name} className="p-6 bg-white rounded-lg shadow">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">{stat.name}</p>
                <p className="text-2xl font-semibold text-gray-900">{stat.value}</p>
              </div>
              <stat.icon className="w-8 h-8 text-gray-400" />
            </div>
            <div className={`mt-2 text-sm ${
              stat.changeType === 'increase' ? 'text-green-600' : 'text-red-600'
            }`}>
              {stat.change}
            </div>
          </div>
        ))}
      </div>

      <div className="grid grid-cols-1 gap-6 lg:grid-cols-2">
        <div className="p-6 bg-white rounded-lg shadow">
          <h3 className="text-lg font-medium text-gray-900">Live Camera Feed</h3>
          <div className="grid grid-cols-2 gap-4 mt-4">
            {[1, 2, 3, 4].map((camera) => (
              <div key={camera} className="relative aspect-video bg-gray-100 rounded-lg overflow-hidden">
                <img
                  src={`https://images.unsplash.com/photo-${1580825180351 + camera}?ixlib=rb-1.2.1&auto=format&fit=crop&w=300&q=80`}
                  alt={`Camera ${camera}`}
                  className="object-cover w-full h-full"
                />
                <div className="absolute bottom-2 left-2 px-2 py-1 text-xs text-white bg-black/50 rounded">
                  Camera {camera}
                </div>
              </div>
            ))}
          </div>
        </div>

        <div className="p-6 bg-white rounded-lg shadow">
          <h3 className="text-lg font-medium text-gray-900">Recent Alerts</h3>
          <div className="mt-4 space-y-4">
            {recentAlerts.map((alert) => (
              <div key={alert.id} className="flex items-center p-4 bg-gray-50 rounded-lg">
                <img
                  src={alert.image}
                  alt={alert.type}
                  className="w-16 h-16 rounded object-cover"
                />
                <div className="ml-4">
                  <p className="font-medium text-gray-900">{alert.type}</p>
                  <p className="text-sm text-gray-600">{alert.location}</p>
                  <p className="text-xs text-gray-500">{alert.time}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}