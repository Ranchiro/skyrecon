import React, { useState } from 'react';
import { AlertTriangle, Search, Download, Filter } from 'lucide-react';

const alerts = [
  {
    id: 1,
    type: 'Face Detection',
    description: 'Unknown person detected in restricted area',
    camera: 'Front Entrance',
    timestamp: '2024-03-15T10:30:00',
    severity: 'high',
    image: 'https://images.unsplash.com/photo-1590674899484-d5640e854abe?ixlib=rb-1.2.1&auto=format&fit=crop&w=300&q=80',
  },
  {
    id: 2,
    type: 'Vehicle Detection',
    description: 'Unauthorized vehicle in loading zone',
    camera: 'Parking Lot',
    timestamp: '2024-03-15T09:45:00',
    severity: 'medium',
    image: 'https://images.unsplash.com/photo-1573167243872-43c6433b9d40?ixlib=rb-1.2.1&auto=format&fit=crop&w=300&q=80',
  },
  {
    id: 3,
    type: 'Crowd Detection',
    description: 'Crowd density exceeds threshold',
    camera: 'Main Entrance',
    timestamp: '2024-03-15T08:15:00',
    severity: 'medium',
    image: 'https://images.unsplash.com/photo-1576427743731-00f27173f10f?ixlib=rb-1.2.1&auto=format&fit=crop&w=300&q=80',
  },
];

export default function AIAlerts() {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedType, setSelectedType] = useState('all');

  const filteredAlerts = alerts.filter((alert) => {
    const matchesSearch = alert.description
      .toLowerCase()
      .includes(searchTerm.toLowerCase());
    const matchesType =
      selectedType === 'all' || alert.type.toLowerCase() === selectedType;
    return matchesSearch && matchesType;
  });

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="text-2xl font-bold text-gray-900">AI Alerts</h2>
        <div className="flex items-center space-x-4">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400 w-5 h-5" />
            <input
              type="text"
              placeholder="Search alerts..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
            />
          </div>
          <select
            value={selectedType}
            onChange={(e) => setSelectedType(e.target.value)}
            className="border border-gray-300 rounded-lg px-4 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
          >
            <option value="all">All Types</option>
            <option value="face detection">Face Detection</option>
            <option value="vehicle detection">Vehicle Detection</option>
            <option value="crowd detection">Crowd Detection</option>
          </select>
          <button className="flex items-center px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700">
            <Download className="w-4 h-4 mr-2" />
            Export
          </button>
        </div>
      </div>

      <div className="bg-white rounded-lg shadow overflow-hidden">
        <div className="divide-y divide-gray-200">
          {filteredAlerts.map((alert) => (
            <div key={alert.id} className="p-6">
              <div className="flex items-start space-x-6">
                <img
                  src={alert.image}
                  alt={alert.type}
                  className="w-32 h-32 object-cover rounded-lg"
                />
                <div className="flex-1">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-2">
                      <span
                        className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${
                          alert.severity === 'high'
                            ? 'bg-red-100 text-red-800'
                            : 'bg-yellow-100 text-yellow-800'
                        }`}
                      >
                        {alert.severity}
                      </span>
                      <h3 className="text-lg font-medium text-gray-900">
                        {alert.type}
                      </h3>
                    </div>
                    <span className="text-sm text-gray-500">
                      {new Date(alert.timestamp).toLocaleString()}
                    </span>
                  </div>
                  <p className="mt-2 text-gray-600">{alert.description}</p>
                  <div className="mt-4 flex items-center justify-between">
                    <span className="text-sm text-gray-500">{alert.camera}</span>
                    <div className="flex space-x-2">
                      <button className="px-3 py-1 text-sm text-blue-600 hover:text-blue-500">
                        View Details
                      </button>
                      <button className="px-3 py-1 text-sm text-red-600 hover:text-red-500">
                        Mark as Resolved
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}