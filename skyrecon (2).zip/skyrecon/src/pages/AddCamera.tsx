import React from 'react';
import PhoneCamera from '../components/PhoneCamera';
import { QrCode } from 'lucide-react';

export default function AddCamera() {
  const handleDetection = (detection: string) => {
    console.log('Detection:', detection);
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="text-2xl font-bold text-gray-900">Add Phone Camera</h2>
      </div>

      <div className="grid grid-cols-1 gap-6 lg:grid-cols-2">
        <div className="bg-white p-6 rounded-lg shadow">
          <h3 className="text-lg font-medium text-gray-900 mb-4">Connect Your Phone</h3>
          <div className="space-y-4">
            <div className="flex items-center justify-center p-8 bg-gray-50 rounded-lg">
              <QrCode className="w-32 h-32 text-gray-400" />
            </div>
            <p className="text-sm text-gray-600 text-center">
              Scan this QR code with your phone's camera to connect it as a surveillance camera
            </p>
          </div>
        </div>

        <div className="bg-white p-6 rounded-lg shadow">
          <h3 className="text-lg font-medium text-gray-900 mb-4">Preview</h3>
          <PhoneCamera onDetection={handleDetection} />
        </div>
      </div>
    </div>
  );
}