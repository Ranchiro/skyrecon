import React from 'react';
import { Camera, Video, Maximize2 } from 'lucide-react';

const cameras = [
  {
    id: 1,
    name: 'Front Entrance',
    location: 'Main Building',
    status: 'online',
    image: 'https://images.unsplash.com/photo-1580825180351-438aa17668b8?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80',
  },
  {
    id: 2,
    name: 'Parking Lot',
    location: 'North Side',
    status: 'online',
    image: 'https://images.unsplash.com/photo-1573167243872-43c6433b9d40?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80',
  },
  {
    id: 3,
    name: 'Back Entrance',
    location: 'Main Building',
    status: 'offline',
    image: 'https://images.unsplash.com/photo-1590674899484-d5640e854abe?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80',
  },
  {
    id: 4,
    name: 'Loading Dock',
    location: 'Warehouse',
    status: 'online',
    image: 'https://images.unsplash.com/photo-1576427743731-00f27173f10f?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80',
  },
];

export default function LiveFeed() {
  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="text-2xl font-bold text-gray-900">Live Camera Feed</h2>
        <div className="flex items-center space-x-4">
          <button className="flex items-center px-4 py-2 text-sm font-medium text-gray-700 bg-white border border-gray-300 rounded-lg hover:bg-gray-50">
            <Camera className="w-4 h-4 mr-2" />
            Add Camera
          </button>
          <button className="flex items-center px-4 py-2 text-sm font-medium text-white bg-blue-600 rounded-lg hover:bg-blue-700">
            <Video className="w-4 h-4 mr-2" />
            Record All
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 gap-6 md:grid-cols-2 lg:grid-cols-2 xl:grid-cols-2">
        {cameras.map((camera) => (
          <div key={camera.id} className="relative overflow-hidden bg-white rounded-lg shadow">
            <div className="relative aspect-video">
              <img
                src={camera.image}
                alt={camera.name}
                className="object-cover w-full h-full"
              />
              <div className="absolute top-4 right-4 space-x-2">
                <button className="p-2 text-white bg-black/50 rounded-lg hover:bg-black/60">
                  <Maximize2 className="w-4 h-4" />
                </button>
              </div>
              <div className="absolute bottom-4 left-4 right-4">
                <div className="flex items-center justify-between">
                  <div className="px-3 py-1 text-sm text-white bg-black/50 rounded-lg">
                    {camera.name}
                  </div>
                  <div className={`px-3 py-1 text-sm rounded-lg ${
                    camera.status === 'online'
                      ? 'bg-green-500/90 text-white'
                      : 'bg-red-500/90 text-white'
                  }`}>
                    {camera.status}
                  </div>
                </div>
              </div>
            </div>
            <div className="p-4 border-t">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-900">{camera.location}</p>
                  <p className="text-sm text-gray-500">Last motion: 2 minutes ago</p>
                </div>
                <div className="flex space-x-2">
                  <button className="p-2 text-gray-400 hover:text-gray-500">
                    <Camera className="w-5 h-5" />
                  </button>
                  <button className="p-2 text-gray-400 hover:text-gray-500">
                    <Video className="w-5 h-5" />
                  </button>
                </div>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}