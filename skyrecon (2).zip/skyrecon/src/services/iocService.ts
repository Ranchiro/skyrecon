import { IOC, DashboardStats } from '../types/ioc';
import { format, subDays, addDays } from 'date-fns';

// Mock IOC data generator
const generateMockIOCs = (): IOC[] => {
  const types: IOC['type'][] = ['ip', 'domain', 'hash', 'url', 'email'];
  const sources = ['VirusTotal', 'OTX AlienVault', 'MISP', 'Shodan', 'ThreatCrowd', 'Hybrid Analysis'];
  const countries = ['US', 'CN', 'RU', 'DE', 'BR', 'IN', 'FR', 'GB', 'CA', 'NL'];
  const malwareFamilies = ['Emotet', 'TrickBot', 'Cobalt Strike', 'Maze', 'APT29', 'Lazarus', 'FIN7'];
  const campaigns = ['APT-2024-001', 'Phishing-Campaign-X', 'Ransomware-Wave-3', 'Banking-Trojan-Y'];

  const iocs: IOC[] = [];

  for (let i = 0; i < 500; i++) {
    const type = types[Math.floor(Math.random() * types.length)];
    const source = sources[Math.floor(Math.random() * sources.length)];
    const country = countries[Math.floor(Math.random() * countries.length)];
    const malwareFamily = malwareFamilies[Math.floor(Math.random() * malwareFamilies.length)];
    const campaign = campaigns[Math.floor(Math.random() * campaigns.length)];

    let value = '';
    switch (type) {
      case 'ip':
        value = `${Math.floor(Math.random() * 256)}.${Math.floor(Math.random() * 256)}.${Math.floor(Math.random() * 256)}.${Math.floor(Math.random() * 256)}`;
        break;
      case 'domain':
        const domains = ['malicious-site.com', 'phishing-bank.net', 'fake-update.org', 'suspicious-download.biz'];
        value = domains[Math.floor(Math.random() * domains.length)];
        break;
      case 'hash':
        value = Array.from({length: 64}, () => Math.floor(Math.random() * 16).toString(16)).join('');
        break;
      case 'url':
        value = `https://malicious-${Math.floor(Math.random() * 1000)}.com/payload.exe`;
        break;
      case 'email':
        value = `attacker${Math.floor(Math.random() * 100)}@suspicious-domain.com`;
        break;
    }

    const firstSeen = subDays(new Date(), Math.floor(Math.random() * 30));
    const lastSeen = addDays(firstSeen, Math.floor(Math.random() * 7));

    iocs.push({
      id: `ioc-${i + 1}`,
      type,
      value,
      source,
      firstSeen,
      lastSeen,
      tags: [malwareFamily, campaign, type, country].slice(0, Math.floor(Math.random() * 3) + 1),
      threatScore: Math.floor(Math.random() * 100),
      confidence: Math.floor(Math.random() * 40) + 60,
      enrichedData: {
        country,
        asn: `AS${Math.floor(Math.random() * 65535)}`,
        organization: `${country} Telecom`,
        malwareFamily,
        campaign,
        detectionRatio: `${Math.floor(Math.random() * 20) + 1}/${Math.floor(Math.random() * 20) + 30}`,
      },
      status: Math.random() > 0.8 ? 'investigating' : Math.random() > 0.1 ? 'active' : 'inactive'
    });
  }

  return iocs;
};

class IOCService {
  private iocs: IOC[] = [];

  constructor() {
    this.iocs = generateMockIOCs();
  }

  async getAllIOCs(): Promise<IOC[]> {
    // Simulate API delay
    await new Promise(resolve => setTimeout(resolve, 500));
    return this.iocs;
  }

  async getIOCById(id: string): Promise<IOC | undefined> {
    await new Promise(resolve => setTimeout(resolve, 200));
    return this.iocs.find(ioc => ioc.id === id);
  }

  async searchIOCs(query: string, filters?: Partial<any>): Promise<IOC[]> {
    await new Promise(resolve => setTimeout(resolve, 300));
    
    let filteredIOCs = this.iocs;

    if (query) {
      const lowerQuery = query.toLowerCase();
      filteredIOCs = filteredIOCs.filter(ioc =>
        ioc.value.toLowerCase().includes(lowerQuery) ||
        ioc.source.toLowerCase().includes(lowerQuery) ||
        ioc.tags.some(tag => tag.toLowerCase().includes(lowerQuery))
      );
    }

    if (filters?.type && filters.type !== 'all') {
      filteredIOCs = filteredIOCs.filter(ioc => ioc.type === filters.type);
    }

    if (filters?.source && filters.source !== 'all') {
      filteredIOCs = filteredIOCs.filter(ioc => ioc.source === filters.source);
    }

    return filteredIOCs;
  }

  async getDashboardStats(): Promise<DashboardStats> {
    await new Promise(resolve => setTimeout(resolve, 400));

    const totalIOCs = this.iocs.length;
    const activeThreats = this.iocs.filter(ioc => ioc.status === 'active').length;
    const today = new Date();
    const newToday = this.iocs.filter(ioc => 
      format(ioc.firstSeen, 'yyyy-MM-dd') === format(today, 'yyyy-MM-dd')
    ).length;
    const highRiskIOCs = this.iocs.filter(ioc => ioc.threatScore > 70).length;

    const sourceDistribution = this.iocs.reduce((acc, ioc) => {
      const existing = acc.find(item => item.source === ioc.source);
      if (existing) {
        existing.count++;
      } else {
        acc.push({ source: ioc.source, count: 1 });
      }
      return acc;
    }, [] as { source: string; count: number; }[]);

    const typeDistribution = this.iocs.reduce((acc, ioc) => {
      const existing = acc.find(item => item.type === ioc.type);
      if (existing) {
        existing.count++;
      } else {
        acc.push({ type: ioc.type, count: 1 });
      }
      return acc;
    }, [] as { type: string; count: number; }[]);

    const threatTrend = Array.from({ length: 7 }, (_, i) => {
      const date = subDays(today, 6 - i);
      const count = this.iocs.filter(ioc =>
        format(ioc.firstSeen, 'yyyy-MM-dd') === format(date, 'yyyy-MM-dd')
      ).length;
      return {
        date: format(date, 'MMM dd'),
        count
      };
    });

    const geoDistribution = this.iocs.reduce((acc, ioc) => {
      const country = ioc.enrichedData.country || 'Unknown';
      const existing = acc.find(item => item.country === country);
      if (existing) {
        existing.count++;
      } else {
        acc.push({ country, count: 1 });
      }
      return acc;
    }, [] as { country: string; count: number; }[]).slice(0, 10);

    return {
      totalIOCs,
      activeThreats,
      newToday,
      highRiskIOCs,
      sourceDistribution,
      typeDistribution,
      threatTrend,
      geoDistribution
    };
  }

  async exportIOCs(exportFormat: 'json' | 'csv'): Promise<string> {
    if (exportFormat === 'json') {
      return JSON.stringify(this.iocs, null, 2);
    } else {
      const headers = ['ID', 'Type', 'Value', 'Source', 'First Seen', 'Threat Score', 'Tags'];
      const rows = this.iocs.map(ioc => [
        ioc.id,
        ioc.type,
        ioc.value,
        ioc.source,
        format(ioc.firstSeen, 'yyyy-MM-dd HH:mm:ss'),
        ioc.threatScore.toString(),
        ioc.tags.join('; ')
      ]);
      
      return [headers, ...rows].map(row => row.join(',')).join('\n');
    }
  }

  async uploadIOCs(file: File): Promise<{ success: boolean; message: string; count?: number }> {
    // Simulate file processing
    await new Promise(resolve => setTimeout(resolve, 1000));
    
    // Mock successful upload
    const newCount = Math.floor(Math.random() * 50) + 10;
    return {
      success: true,
      message: `Successfully imported ${newCount} IOCs from ${file.name}`,
      count: newCount
    };
  }
}

export const iocService = new IOCService();