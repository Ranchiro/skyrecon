from flask import Flask, render_template, request, redirect, url_for, flash, jsonify, Response
import csv
import io
import os
import sqlite3
import json
from datetime import datetime
from werkzeug.utils import secure_filename
import pandas as pd

app = Flask(__name__, template_folder="templates", static_folder="../static")
app.secret_key = 'your-secret-key-here'  # Change this in production

# Configuration
UPLOAD_FOLDER = 'uploads'
ALLOWED_EXTENSIONS = {'csv'}
DATABASE_PATH = 'skyrecon.db'

# Ensure upload directory exists
os.makedirs(UPLOAD_FOLDER, exist_ok=True)

def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

def init_database():
    """Initialize the SQLite database with IOC table"""
    conn = sqlite3.connect(DATABASE_PATH)
    cursor = conn.cursor()
    
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS iocs (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            type TEXT NOT NULL,
            value TEXT NOT NULL,
            source TEXT NOT NULL,
            first_seen TEXT NOT NULL,
            last_seen TEXT,
            tags TEXT,
            threat_score INTEGER DEFAULT 0,
            confidence INTEGER DEFAULT 0,
            enriched_data TEXT,
            status TEXT DEFAULT 'active',
            UNIQUE(type, value, source)
        )
    ''')
    
    conn.commit()
    conn.close()

def insert_ioc(ioc_data):
    """Insert IOC into database with deduplication"""
    conn = sqlite3.connect(DATABASE_PATH)
    cursor = conn.cursor()
    
    try:
        cursor.execute('''
            INSERT OR REPLACE INTO iocs 
            (type, value, source, first_seen, last_seen, tags, threat_score, confidence, enriched_data, status)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        ''', (
            ioc_data.get('type', ''),
            ioc_data.get('value', ''),
            ioc_data.get('source', ''),
            ioc_data.get('first_seen', ''),
            ioc_data.get('last_seen', ''),
            json.dumps(ioc_data.get('tags', [])),
            ioc_data.get('threat_score', 0),
            ioc_data.get('confidence', 0),
            json.dumps(ioc_data.get('enriched_data', {})),
            ioc_data.get('status', 'active')
        ))
        conn.commit()
        return True
    except Exception as e:
        print(f"Error inserting IOC: {e}")
        return False
    finally:
        conn.close()

def fetch_all_iocs():
    """Fetch all IOCs from database"""
    conn = sqlite3.connect(DATABASE_PATH)
    cursor = conn.cursor()
    
    cursor.execute('SELECT * FROM iocs ORDER BY first_seen DESC')
    rows = cursor.fetchall()
    conn.close()
    
    iocs = []
    for row in rows:
        ioc = {
            'id': row[0],
            'type': row[1],
            'value': row[2],
            'source': row[3],
            'first_seen': row[4],
            'last_seen': row[5],
            'tags': json.loads(row[6]) if row[6] else [],
            'threat_score': row[7],
            'confidence': row[8],
            'enriched_data': json.loads(row[9]) if row[9] else {},
            'status': row[10]
        }
        iocs.append(ioc)
    
    return iocs

def enrich_ioc(ioc_data):
    """Basic enrichment - can be expanded with real APIs"""
    enriched = ioc_data.copy()
    
    # Add basic enrichment based on type
    if ioc_data['type'].lower() == 'ip':
        enriched['enriched_data'] = {
            'country': 'Unknown',
            'asn': 'Unknown',
            'organization': 'Unknown'
        }
    elif ioc_data['type'].lower() == 'domain':
        enriched['enriched_data'] = {
            'registrar': 'Unknown',
            'creation_date': 'Unknown'
        }
    elif ioc_data['type'].lower() == 'hash':
        enriched['enriched_data'] = {
            'detection_ratio': '0/0',
            'malware_family': 'Unknown'
        }
    
    # Set default threat score based on type
    threat_scores = {'ip': 50, 'domain': 40, 'hash': 70, 'url': 60, 'email': 45}
    enriched['threat_score'] = threat_scores.get(ioc_data['type'].lower(), 30)
    enriched['confidence'] = 75  # Default confidence
    
    return enriched

def process_csv_file(filepath):
    """Process uploaded CSV file and extract IOCs"""
    processed_count = 0
    error_count = 0
    errors = []
    
    try:
        # Try pandas first for better CSV handling
        pandas_version = tuple(map(int, pd.__version__.split('.')[:2]))
        if pandas_version >= (1, 3):
            df = pd.read_csv(filepath, quotechar='"', skipinitialspace=True, engine="python", on_bad_lines='skip')
        else:
            df = pd.read_csv(filepath, quotechar='"', skipinitialspace=True, engine="python")
        
        # Normalize column names (case insensitive)
        df.columns = df.columns.str.lower().str.strip()
        
        # Required columns
        required_cols = ['type', 'value', 'source']
        missing_cols = [col for col in required_cols if col not in df.columns]
        
        if missing_cols:
            return 0, 1, [f"Missing required columns: {', '.join(missing_cols)}"]
        
        for index, row in df.iterrows():
            try:
                # Extract IOC data
                ioc_data = {
                    'type': str(row['type']).strip().lower(),
                    'value': str(row['value']).strip(),
                    'source': str(row['source']).strip(),
                    'first_seen': row['first_seen'] if 'first_seen' in row and pd.notna(row['first_seen']) else datetime.now().isoformat(),
                    'last_seen': row['last_seen'] if 'last_seen' in row and pd.notna(row['last_seen']) else datetime.now().isoformat(),
                    'tags': str(row['tags']).split(',') if 'tags' in row and pd.notna(row['tags']) else [],
                    'status': str(row['status']).strip().lower() if 'status' in row and pd.notna(row['status']) else 'active'
                }
                
                # Validate IOC type
                valid_types = ['ip', 'domain', 'hash', 'url', 'email']
                if ioc_data['type'] not in valid_types:
                    errors.append(f"Row {str(index)}: Invalid IOC type '{ioc_data['type']}'")
                    error_count += 1
                    continue
                
                # Validate required fields
                if not ioc_data['value'] or not ioc_data['source']:
                    errors.append(f"Row {str(index)}: Missing value or source")
                    error_count += 1
                    continue
                
                # Enrich and insert IOC
                enriched_ioc = enrich_ioc(ioc_data)
                
                if insert_ioc(enriched_ioc):
                    processed_count += 1
                else:
                    error_count += 1
                    errors.append(f"Row {str(index)}: Database insertion failed")
                    
            except Exception as e:
                error_count += 1
                errors.append(f"Row {str(index)}: {str(e)}")
                
    except Exception as e:
        return 0, 1, [f"Failed to read CSV file: {str(e)}"]
    
    return processed_count, error_count, errors

@app.route('/')
def index():
    return redirect(url_for('dashboard'))

@app.route('/dashboard')
def dashboard():
    """Main dashboard view"""
    iocs = fetch_all_iocs()
    
    # Calculate stats
    stats = {
        'total_iocs': len(iocs),
        'active_threats': len([ioc for ioc in iocs if ioc['status'] == 'active']),
        'high_risk': len([ioc for ioc in iocs if ioc['threat_score'] > 70]),
        'sources': len(set(ioc['source'] for ioc in iocs))
    }
    
    return render_template('dashboard.html', iocs=iocs, stats=stats)

@app.route('/upload', methods=['POST'])
def upload_file():
    """Handle file upload and IOC processing"""
    if 'file' not in request.files:
        flash('No file selected', 'error')
        return redirect(url_for('dashboard'))
    
    file = request.files['file']
    
    if not file or not getattr(file, 'filename', None):
        flash('No file selected', 'error')
        return redirect(url_for('dashboard'))
    
    if not allowed_file(file.filename):
        flash('Invalid file type. Please upload a CSV file.', 'error')
        return redirect(url_for('dashboard'))
    
    try:
        # Save uploaded file
        filename = secure_filename(str(file.filename))
        timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
        filename = f"{timestamp}_{filename}"
        filepath = os.path.join(UPLOAD_FOLDER, filename)
        file.save(filepath)
        
        # Process the CSV file
        processed_count, error_count, errors = process_csv_file(filepath)
        
        # Clean up uploaded file
        os.remove(filepath)
        
        # Show results to user
        if processed_count > 0:
            flash(f'Successfully processed {processed_count} IOCs from {file.filename}', 'success')
        
        if error_count > 0:
            flash(f'{error_count} errors occurred during processing', 'warning')
            for error in errors[:5]:  # Show first 5 errors
                flash(error, 'error')
        
        if processed_count == 0 and error_count == 0:
            flash('No valid IOCs found in the uploaded file', 'warning')
            
    except Exception as e:
        flash(f'Upload failed: {str(e)}', 'error')
    
    return redirect(url_for('dashboard'))

@app.route('/export/json')
def export_json():
    """Export IOCs as JSON"""
    iocs = fetch_all_iocs()
    return jsonify(iocs)

@app.route('/export/csv')
def export_csv():
    """Export IOCs as CSV"""
    iocs = fetch_all_iocs()
    
    output = io.StringIO()
    writer = csv.writer(output)
    
    # Write header
    writer.writerow(['Type', 'Value', 'Source', 'First Seen', 'Tags', 'Threat Score', 'Status'])
    
    # Write data
    for ioc in iocs:
        writer.writerow([
            ioc['type'],
            ioc['value'],
            ioc['source'],
            ioc['first_seen'],
            ','.join(ioc['tags']),
            ioc['threat_score'],
            ioc['status']
        ])
    
    output.seek(0)
    return Response(
        output.getvalue(),
        mimetype='text/csv',
        headers={"Content-Disposition": "attachment;filename=skyrecon_iocs.csv"}
    )

@app.route('/clear')
def clear_database():
    """Clear all IOCs from database (for testing)"""
    conn = sqlite3.connect(DATABASE_PATH)
    cursor = conn.cursor()
    cursor.execute('DELETE FROM iocs')
    conn.commit()
    conn.close()
    
    flash('Database cleared successfully', 'success')
    return redirect(url_for('dashboard'))

if __name__ == '__main__':
    init_database()
    app.run(debug=True, host='0.0.0.0', port=5000)