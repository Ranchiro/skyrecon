import { create } from 'zustand';
import { persist } from 'zustand/middleware';

export interface Recording {
  id: string;
  cameraId: string;
  startTime: Date;
  endTime: Date;
  type: 'scheduled' | 'motion' | 'manual';
  fileSize: number;
  location: 'cloud' | 'local';
  url: string;
  thumbnail: string;
  tags: string[];
  events: {
    timestamp: Date;
    type: string;
    description: string;
  }[];
}

interface RecordingState {
  recordings: Recording[];
  schedules: {
    id: string;
    cameraId: string;
    days: number[];
    startTime: string;
    endTime: string;
    enabled: boolean;
  }[];
  retentionDays: number;
  addRecording: (recording: Recording) => void;
  deleteRecording: (id: string) => void;
  updateRecording: (id: string, updates: Partial<Recording>) => void;
  addSchedule: (schedule: any) => void;
  updateSchedule: (id: string, updates: any) => void;
  deleteSchedule: (id: string) => void;
  setRetentionDays: (days: number) => void;
  cleanupOldRecordings: () => void;
}

export const useRecordingStore = create<RecordingState>()(
  persist(
    (set) => ({
      recordings: [],
      schedules: [],
      retentionDays: 30,

      addRecording: (recording) =>
        set((state) => ({
          recordings: [...state.recordings, recording],
        })),

      deleteRecording: (id) =>
        set((state) => ({
          recordings: state.recordings.filter((rec) => rec.id !== id),
        })),

      updateRecording: (id, updates) =>
        set((state) => ({
          recordings: state.recordings.map((rec) =>
            rec.id === id ? { ...rec, ...updates } : rec
          ),
        })),

      addSchedule: (schedule) =>
        set((state) => ({
          schedules: [...state.schedules, schedule],
        })),

      updateSchedule: (id, updates) =>
        set((state) => ({
          schedules: state.schedules.map((sch) =>
            sch.id === id ? { ...sch, ...updates } : sch
          ),
        })),

      deleteSchedule: (id) =>
        set((state) => ({
          schedules: state.schedules.filter((sch) => sch.id !== id),
        })),

      setRetentionDays: (days) =>
        set({ retentionDays: days }),

      cleanupOldRecordings: () =>
        set((state) => {
          const cutoffDate = new Date();
          cutoffDate.setDate(cutoffDate.getDate() - state.retentionDays);
          return {
            recordings: state.recordings.filter(
              (rec) => new Date(rec.endTime) > cutoffDate
            ),
          };
        }),
    }),
    {
      name: 'recording-storage',
    }
  )
);