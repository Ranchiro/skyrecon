import { create } from 'zustand';

export interface Camera {
  id: string;
  name: string;
  location: string;
  status: 'online' | 'offline' | 'error';
  type: 'fixed' | 'ptz';
  streamUrl: string;
  thumbnail: string;
  resolution: '720p' | '1080p';
  recording: boolean;
  motionDetection: boolean;
  lastMotion: Date | null;
  tags: string[];
  ptzControls?: {
    pan: number;
    tilt: number;
    zoom: number;
  };
}

interface CameraState {
  cameras: Camera[];
  selectedCamera: string | null;
  layout: 'grid' | 'single' | 'custom';
  gridSize: number;
  addCamera: (camera: Camera) => void;
  removeCamera: (id: string) => void;
  updateCamera: (id: string, updates: Partial<Camera>) => void;
  setSelectedCamera: (id: string | null) => void;
  setLayout: (layout: 'grid' | 'single' | 'custom') => void;
  setGridSize: (size: number) => void;
  controlPTZ: (id: string, pan: number, tilt: number, zoom: number) => void;
}

export const useCameraStore = create<CameraState>((set) => ({
  cameras: [
    {
      id: '1',
      name: 'Front Entrance',
      location: 'Main Building',
      status: 'online',
      type: 'ptz',
      streamUrl: 'https://example.com/stream1',
      thumbnail: 'https://images.unsplash.com/photo-1590674899484-d5640e854abe',
      resolution: '1080p',
      recording: true,
      motionDetection: true,
      lastMotion: new Date(),
      tags: ['entrance', 'security'],
      ptzControls: { pan: 0, tilt: 0, zoom: 1 },
    },
    // Add more sample cameras here
  ],
  selectedCamera: null,
  layout: 'grid',
  gridSize: 2,

  addCamera: (camera) =>
    set((state) => ({ cameras: [...state.cameras, camera] })),

  removeCamera: (id) =>
    set((state) => ({
      cameras: state.cameras.filter((cam) => cam.id !== id),
    })),

  updateCamera: (id, updates) =>
    set((state) => ({
      cameras: state.cameras.map((cam) =>
        cam.id === id ? { ...cam, ...updates } : cam
      ),
    })),

  setSelectedCamera: (id) => set({ selectedCamera: id }),

  setLayout: (layout) => set({ layout }),

  setGridSize: (size) => set({ gridSize: size }),

  controlPTZ: (id, pan, tilt, zoom) =>
    set((state) => ({
      cameras: state.cameras.map((cam) =>
        cam.id === id
          ? {
              ...cam,
              ptzControls: { pan, tilt, zoom },
            }
          : cam
      ),
    })),
}));