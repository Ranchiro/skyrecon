import { create } from 'zustand';
import { persist } from 'zustand/middleware';

interface User {
  id: string;
  email: string;
  name: string;
  role: 'admin' | 'manager' | 'viewer';
  twoFactorEnabled: boolean;
  lastLogin: Date;
  ipAddress: string;
  sessionTimeout: number;
  allowedIPs: string[];
  profileImage?: string;
}

interface AuthState {
  user: User | null;
  isAuthenticated: boolean;
  isVerifying2FA: boolean;
  sessionExpiresAt: Date | null;
  login: (email: string, password: string) => Promise<void>;
  verify2FA: (code: string) => Promise<void>;
  logout: () => void;
  resetPassword: (email: string) => Promise<void>;
  updateProfile: (userData: Partial<User>) => Promise<void>;
  checkSession: () => boolean;
  refreshSession: () => void;
}

const SESSION_TIMEOUT = 30 * 60 * 1000; // 30 minutes

export const useAuthStore = create<AuthState>()(
  persist(
    (set, get) => ({
      user: null,
      isAuthenticated: false,
      isVerifying2FA: false,
      sessionExpiresAt: null,

      login: async (email: string, password: string) => {
        // Simulate API call
        if (email === 'admin@example.com' && password === 'password') {
          const ipAddress = await fetch('https://api.ipify.org?format=json')
            .then(res => res.json())
            .then(data => data.ip);

          set({
            isVerifying2FA: true,
            user: {
              id: '1',
              email,
              name: 'John Doe',
              role: 'admin',
              twoFactorEnabled: true,
              lastLogin: new Date(),
              ipAddress,
              sessionTimeout: SESSION_TIMEOUT,
              allowedIPs: ['*'],
              profileImage: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e',
            },
          });
        } else {
          throw new Error('Invalid credentials');
        }
      },

      verify2FA: async (code: string) => {
        if (code === '123456') {
          const expiresAt = new Date(Date.now() + SESSION_TIMEOUT);
          set((state) => ({
            isAuthenticated: true,
            isVerifying2FA: false,
            sessionExpiresAt: expiresAt,
            user: {
              ...state.user!,
              lastLogin: new Date(),
            },
          }));
        } else {
          throw new Error('Invalid 2FA code');
        }
      },

      logout: () => {
        set({
          user: null,
          isAuthenticated: false,
          isVerifying2FA: false,
          sessionExpiresAt: null,
        });
      },

      resetPassword: async (email: string) => {
        // Simulate password reset email
        console.log(`Password reset email sent to ${email}`);
      },

      updateProfile: async (userData: Partial<User>) => {
        set((state) => ({
          user: state.user ? { ...state.user, ...userData } : null,
        }));
      },

      checkSession: () => {
        const state = get();
        if (!state.sessionExpiresAt) return false;
        if (new Date() > state.sessionExpiresAt) {
          state.logout();
          return false;
        }
        return true;
      },

      refreshSession: () => {
        set({
          sessionExpiresAt: new Date(Date.now() + SESSION_TIMEOUT),
        });
      },
    }),
    {
      name: 'auth-storage',
      partialize: (state) => ({
        user: state.user,
        isAuthenticated: state.isAuthenticated,
        sessionExpiresAt: state.sessionExpiresAt,
      }),
    }
  )
);