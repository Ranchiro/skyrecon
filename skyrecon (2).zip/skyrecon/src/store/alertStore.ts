import { create } from 'zustand';
import { persist } from 'zustand/middleware';

export interface Alert {
  id: string;
  timestamp: Date;
  type: 'motion' | 'face' | 'object' | 'vehicle' | 'crowd' | 'behavior';
  cameraId: string;
  severity: 'low' | 'medium' | 'high';
  description: string;
  image: string;
  status: 'new' | 'acknowledged' | 'resolved';
  assignedTo?: string;
  resolution?: string;
  metadata: Record<string, any>;
}

interface AlertRule {
  id: string;
  name: string;
  type: string;
  conditions: {
    field: string;
    operator: string;
    value: any;
  }[];
  actions: {
    type: 'notification' | 'email' | 'sms' | 'webhook';
    config: Record<string, any>;
  }[];
  schedule?: {
    days: number[];
    startTime: string;
    endTime: string;
  };
  enabled: boolean;
}

interface AlertState {
  alerts: Alert[];
  rules: AlertRule[];
  addAlert: (alert: Alert) => void;
  updateAlert: (id: string, updates: Partial<Alert>) => void;
  deleteAlert: (id: string) => void;
  addRule: (rule: AlertRule) => void;
  updateRule: (id: string, updates: Partial<AlertRule>) => void;
  deleteRule: (id: string) => void;
  getActiveRules: () => AlertRule[];
  acknowledgeAlert: (id: string, userId: string) => void;
  resolveAlert: (id: string, resolution: string) => void;
  getAlertStats: () => {
    total: number;
    unresolved: number;
    byType: Record<string, number>;
    bySeverity: Record<string, number>;
  };
}

export const useAlertStore = create<AlertState>()(
  persist(
    (set, get) => ({
      alerts: [],
      rules: [],

      addAlert: (alert) =>
        set((state) => ({
          alerts: [alert, ...state.alerts],
        })),

      updateAlert: (id, updates) =>
        set((state) => ({
          alerts: state.alerts.map((alert) =>
            alert.id === id ? { ...alert, ...updates } : alert
          ),
        })),

      deleteAlert: (id) =>
        set((state) => ({
          alerts: state.alerts.filter((alert) => alert.id !== id),
        })),

      addRule: (rule) =>
        set((state) => ({
          rules: [...state.rules, rule],
        })),

      updateRule: (id, updates) =>
        set((state) => ({
          rules: state.rules.map((rule) =>
            rule.id === id ? { ...rule, ...updates } : rule
          ),
        })),

      deleteRule: (id) =>
        set((state) => ({
          rules: state.rules.filter((rule) => rule.id !== id),
        })),

      getActiveRules: () => {
        const state = get();
        const now = new Date();
        const currentHour = now.getHours();
        const currentMinute = now.getMinutes();
        const currentDay = now.getDay();

        return state.rules.filter((rule) => {
          if (!rule.enabled) return false;
          if (!rule.schedule) return true;

          const { days, startTime, endTime } = rule.schedule;
          if (!days.includes(currentDay)) return false;

          const [startHour, startMinute] = startTime.split(':').map(Number);
          const [endHour, endMinute] = endTime.split(':').map(Number);
          const current = currentHour * 60 + currentMinute;
          const start = startHour * 60 + startMinute;
          const end = endHour * 60 + endMinute;

          return current >= start && current <= end;
        });
      },

      acknowledgeAlert: (id, userId) =>
        set((state) => ({
          alerts: state.alerts.map((alert) =>
            alert.id === id
              ? {
                  ...alert,
                  status: 'acknowledged',
                  assignedTo: userId,
                }
              : alert
          ),
        })),

      resolveAlert: (id, resolution) =>
        set((state) => ({
          alerts: state.alerts.map((alert) =>
            alert.id === id
              ? {
                  ...alert,
                  status: 'resolved',
                  resolution,
                }
              : alert
          ),
        })),

      getAlertStats: () => {
        const state = get();
        return {
          total: state.alerts.length,
          unresolved: state.alerts.filter(
            (alert) => alert.status !== 'resolved'
          ).length,
          byType: state.alerts.reduce((acc, alert) => {
            acc[alert.type] = (acc[alert.type] || 0) + 1;
            return acc;
          }, {} as Record<string, number>),
          bySeverity: state.alerts.reduce((acc, alert) => {
            acc[alert.severity] = (acc[alert.severity] || 0) + 1;
            return acc;
          }, {} as Record<string, number>),
        };
      },
    }),
    {
      name: 'alert-storage',
    }
  )
);