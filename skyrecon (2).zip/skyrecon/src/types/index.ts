export interface User {
  id: string;
  name: string;
  email: string;
  role: 'admin' | 'operator' | 'viewer';
  avatar: string;
}

export interface Alert {
  id: string;
  timestamp: string;
  type: 'motion' | 'person' | 'vehicle' | 'unauthorized';
  camera: string;
  severity: 'low' | 'medium' | 'high';
  thumbnail: string;
  description: string;
}

export interface Camera {
  id: string;
  name: string;
  location: string;
  status: 'online' | 'offline';
  thumbnail: string;
  lastActive: string;
}