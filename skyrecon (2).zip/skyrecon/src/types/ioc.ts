export interface IOC {
  id: string;
  type: 'ip' | 'domain' | 'hash' | 'url' | 'email';
  value: string;
  source: string;
  firstSeen: Date;
  lastSeen: Date;
  tags: string[];
  threatScore: number;
  confidence: number;
  enrichedData: {
    country?: string;
    asn?: string;
    organization?: string;
    malwareFamily?: string;
    campaign?: string;
    detectionRatio?: string;
    whoisData?: any;
  };
  status: 'active' | 'inactive' | 'investigating';
}

export interface DashboardStats {
  totalIOCs: number;
  activeThreats: number;
  newToday: number;
  highRiskIOCs: number;
  sourceDistribution: { source: string; count: number; }[];
  typeDistribution: { type: string; count: number; }[];
  threatTrend: { date: string; count: number; }[];
  geoDistribution: { country: string; count: number; }[];
}

export interface SearchFilters {
  query: string;
  type: string;
  source: string;
  threatScore: [number, number];
  dateRange: [Date | null, Date | null];
  tags: string[];
}