import sqlite3
import json
from datetime import datetime
import os

DATABASE_PATH = 'skyrecon.db'

class IOCDatabase:
    def __init__(self, db_path=DATABASE_PATH):
        self.db_path = db_path
        self.init_database()
    
    def init_database(self):
        """Initialize the SQLite database with IOC table"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS iocs (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                type TEXT NOT NULL,
                value TEXT NOT NULL,
                source TEXT NOT NULL,
                first_seen TEXT NOT NULL,
                last_seen TEXT,
                tags TEXT,
                threat_score INTEGER DEFAULT 0,
                confidence INTEGER DEFAULT 0,
                enriched_data TEXT,
                status TEXT DEFAULT 'active',
                created_at TEXT DEFAULT CURRENT_TIMESTAMP,
                UNIQUE(type, value, source)
            )
        ''')
        
        # Create indexes for better performance
        cursor.execute('CREATE INDEX IF NOT EXISTS idx_type ON iocs(type)')
        cursor.execute('CREATE INDEX IF NOT EXISTS idx_value ON iocs(value)')
        cursor.execute('CREATE INDEX IF NOT EXISTS idx_source ON iocs(source)')
        cursor.execute('CREATE INDEX IF NOT EXISTS idx_threat_score ON iocs(threat_score)')
        cursor.execute('CREATE INDEX IF NOT EXISTS idx_status ON iocs(status)')
        
        conn.commit()
        conn.close()
    
    def insert_ioc(self, ioc_data):
        """Insert IOC into database with deduplication"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        try:
            cursor.execute('''
                INSERT OR REPLACE INTO iocs 
                (type, value, source, first_seen, last_seen, tags, threat_score, confidence, enriched_data, status)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            ''', (
                ioc_data.get('type', ''),
                ioc_data.get('value', ''),
                ioc_data.get('source', ''),
                ioc_data.get('first_seen', datetime.now().isoformat()),
                ioc_data.get('last_seen', datetime.now().isoformat()),
                json.dumps(ioc_data.get('tags', [])),
                ioc_data.get('threat_score', 0),
                ioc_data.get('confidence', 0),
                json.dumps(ioc_data.get('enriched_data', {})),
                ioc_data.get('status', 'active')
            ))
            conn.commit()
            return True
        except Exception as e:
            print(f"Error inserting IOC: {e}")
            return False
        finally:
            conn.close()
    
    def fetch_all_iocs(self):
        """Fetch all IOCs from database"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        cursor.execute('SELECT * FROM iocs ORDER BY first_seen DESC')
        rows = cursor.fetchall()
        conn.close()
        
        iocs = []
        for row in rows:
            ioc = {
                'id': row[0],
                'type': row[1],
                'value': row[2],
                'source': row[3],
                'first_seen': row[4],
                'last_seen': row[5],
                'tags': json.loads(row[6]) if row[6] else [],
                'threat_score': row[7],
                'confidence': row[8],
                'enriched_data': json.loads(row[9]) if row[9] else {},
                'status': row[10],
                'created_at': row[11] if len(row) > 11 else None
            }
            iocs.append(ioc)
        
        return iocs
    
    def search_iocs(self, query=None, ioc_type=None, source=None, min_threat_score=None):
        """Search IOCs with filters"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        sql = "SELECT * FROM iocs WHERE 1=1"
        params = []
        
        if query:
            sql += " AND (value LIKE ? OR tags LIKE ?)"
            params.extend([f"%{query}%", f"%{query}%"])
        
        if ioc_type:
            sql += " AND type = ?"
            params.append(ioc_type)
        
        if source:
            sql += " AND source = ?"
            params.append(source)
        
        if min_threat_score:
            sql += " AND threat_score >= ?"
            params.append(min_threat_score)
        
        sql += " ORDER BY first_seen DESC"
        
        cursor.execute(sql, params)
        rows = cursor.fetchall()
        conn.close()
        
        iocs = []
        for row in rows:
            ioc = {
                'id': row[0],
                'type': row[1],
                'value': row[2],
                'source': row[3],
                'first_seen': row[4],
                'last_seen': row[5],
                'tags': json.loads(row[6]) if row[6] else [],
                'threat_score': row[7],
                'confidence': row[8],
                'enriched_data': json.loads(row[9]) if row[9] else {},
                'status': row[10]
            }
            iocs.append(ioc)
        
        return iocs
    
    def get_stats(self):
        """Get database statistics"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        # Total IOCs
        cursor.execute("SELECT COUNT(*) FROM iocs")
        total_iocs = cursor.fetchone()[0]
        
        # Active threats
        cursor.execute("SELECT COUNT(*) FROM iocs WHERE status = 'active'")
        active_threats = cursor.fetchone()[0]
        
        # High risk IOCs
        cursor.execute("SELECT COUNT(*) FROM iocs WHERE threat_score > 70")
        high_risk = cursor.fetchone()[0]
        
        # Unique sources
        cursor.execute("SELECT COUNT(DISTINCT source) FROM iocs")
        sources = cursor.fetchone()[0]
        
        # Type distribution
        cursor.execute("SELECT type, COUNT(*) FROM iocs GROUP BY type")
        type_dist = cursor.fetchall()
        
        # Source distribution
        cursor.execute("SELECT source, COUNT(*) FROM iocs GROUP BY source")
        source_dist = cursor.fetchall()
        
        conn.close()
        
        return {
            'total_iocs': total_iocs,
            'active_threats': active_threats,
            'high_risk': high_risk,
            'sources': sources,
            'type_distribution': dict(type_dist),
            'source_distribution': dict(source_dist)
        }
    
    def clear_all(self):
        """Clear all IOCs from database"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        cursor.execute('DELETE FROM iocs')
        conn.commit()
        conn.close()
    
    def delete_ioc(self, ioc_id):
        """Delete specific IOC by ID"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        cursor.execute('DELETE FROM iocs WHERE id = ?', (ioc_id,))
        conn.commit()
        conn.close()

# Global database instance
db = IOCDatabase()